package com.example.soham.test.converter;

import com.example.soham.test.dto.TeacherDto;
import com.example.soham.test.requestbody.TeacherRequestBody;

import java.util.List;
import java.util.stream.Collectors;

public class TeacherConverter {
    public TeacherDto entityToDto(TeacherRequestBody teacher)
    {
        TeacherDto dto = new TeacherDto();
        dto.setId(teacher.getId());
        dto.setTname(teacher.getTname());
        return dto;
    }
    public List<TeacherDto> entityToDto(List<TeacherRequestBody> teacher)
    {
        return teacher.stream().map(x->entityToDto(x)).collect(Collectors.toList());
    }
    public TeacherRequestBody dtoToEntity(TeacherDto dto)
    {
        TeacherRequestBody tc = new TeacherRequestBody();
        tc.setId(dto.getId());
        tc.setTname(dto.getTname());
        return tc;
    }
    public List<TeacherRequestBody> dtoToEntity(List<TeacherDto> dto)
    {
        return dto.stream().map(x->dtoToEntity(x)).collect(Collectors.toList());
    }
}
