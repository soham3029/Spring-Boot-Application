package com.example.soham.test.dao;

import com.example.soham.test.dto.ControllerDto;
import com.example.soham.test.model.Controller;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ControllerRepository extends JpaRepository<Controller, Integer> {
    //@Query("delete from Controller  c where c.id =: id")
    //void deleteById(int id);
}
