package com.example.soham.test.serviceimplementation;

import com.example.soham.test.dao.DepartmentRepository;
import com.example.soham.test.dao.TeacherRepository;
import com.example.soham.test.dto.TeacherDto;
import com.example.soham.test.model.Department;
import com.example.soham.test.model.Teacher;
import com.example.soham.test.requestbody.TeacherRequestBody;
import com.example.soham.test.serviceinterface.TeacherInterface;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TeacherImpl implements TeacherInterface {
    @Autowired
    TeacherRepository repo;
    @Autowired
    DepartmentRepository deptrepo;
    @Override
    public Teacher saveTeacher(TeacherRequestBody teacher) {
        Teacher tc = new Teacher();
        BeanUtils.copyProperties(teacher, tc);
        return repo.save(tc);
    }

    @Override
    public Teacher updateTeacher(TeacherRequestBody teacher) {
        Teacher tc = new Teacher();
        BeanUtils.copyProperties(teacher, tc);
        Department dept = deptrepo.findById(teacher.getDid());
        tc.setDept(dept);
        return repo.save(tc);
    }

    @Override
    public void deleteByTid(int id) {
    repo.deleteById(id);
    }
    public List<TeacherDto> findByDeptId(int id)
    {
        return repo.findByDeptId(id);
    }
}
