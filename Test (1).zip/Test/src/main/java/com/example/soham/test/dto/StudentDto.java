package com.example.soham.test.dto;

import com.example.soham.test.model.Department;

import java.util.Optional;

public class StudentDto {
    private int id;
    private String name;
    private String email;

    public Department getDept() {
        return dept;
    }

    public void setDept(Department dept) {
        this.dept = dept;
    }

    private int marks;

    public StudentDto(String name) {
        this.name = name;
    }

    public StudentDto(String name, String email) {
        super();
        this.name = name;
        this.email = email;
    }

    public StudentDto() {
        super();
    }

    Department dept;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }
}
