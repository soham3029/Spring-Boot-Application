package com.example.soham.test.serviceinterface;

import com.example.soham.test.model.Department;
import com.example.soham.test.requestbody.DepartmentRequestBody;

public interface DepartmentInterface {
    public Department saveDepartment(DepartmentRequestBody dept);
    public Department updateDepartment(DepartmentRequestBody dept);
}
