package com.example.soham.test.dao;

import com.example.soham.test.dto.TeacherDto;
import com.example.soham.test.model.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, Integer> {
    @Query("Select new com.example.soham.test.dto.TeacherDto(t.tname) from Teacher t join t.dept dt where dt.id = :id")
    public List<TeacherDto> findByDeptId(@Param("id") int id);
    public Teacher findById(int id);
}
