package com.example.soham.test.serviceimplementation;

import com.example.soham.test.dao.ControllerRepository;
import com.example.soham.test.dao.DepartmentRepository;
import com.example.soham.test.dao.StudentRepository;
import com.example.soham.test.dao.TeacherRepository;
import com.example.soham.test.dto.ControllerDto;
import com.example.soham.test.model.Controller;
import com.example.soham.test.model.Department;
import com.example.soham.test.model.Student;
import com.example.soham.test.model.Teacher;
import com.example.soham.test.requestbody.ControllerRequestBody;
import com.example.soham.test.serviceinterface.ControllerInterface;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

@Service
public class ControllerImpl implements ControllerInterface {
    @Autowired
    private ControllerRepository repo;
    @Autowired
    private DepartmentRepository depRepo;
    @Autowired
    private StudentRepository stuRepo;
    @Autowired
    private TeacherRepository tcRepo;
    @Override
    public Controller saveController(ControllerRequestBody cr) {
        Controller ct = new Controller();
        BeanUtils.copyProperties(cr, ct);
        Department dept = depRepo.findById(cr.getDid());
        ct.setDept(dept);
        Student st = stuRepo.findById(cr.getSid());
        ct.setStudent(st);
        Teacher tc = tcRepo.findById(cr.getTid());
        ct.setTeacher(tc);
        return repo.save(ct);
    }

    @Override
    public Controller updateController(ControllerRequestBody cr) {
        Controller cnr = new Controller();
        BeanUtils.copyProperties(cr, cnr);
        return repo.save(cnr);
    }
    @Override
    public void deleteById(int id)
    {
        repo.deleteById(id);
    }
}
