package com.example.soham.test.serviceinterface;

import com.example.soham.test.model.Teacher;
import com.example.soham.test.requestbody.TeacherRequestBody;

public interface TeacherInterface {
    public Teacher saveTeacher(TeacherRequestBody teacher);
    public Teacher updateTeacher(TeacherRequestBody teacher);
    public void deleteByTid(int id);
}
