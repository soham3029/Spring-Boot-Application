package com.example.soham.test.serviceimplementation;

import com.example.soham.test.dao.DepartmentRepository;
import com.example.soham.test.model.Department;
import com.example.soham.test.requestbody.DepartmentRequestBody;
import com.example.soham.test.serviceinterface.DepartmentInterface;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartmentImpl implements DepartmentInterface {
    @Autowired
    DepartmentRepository repo;
    @Override
    public Department saveDepartment(DepartmentRequestBody dept) {
        Department dt = new Department();
        BeanUtils.copyProperties(dept, dt);
        return repo.save(dt);
    }

    @Override
    public Department updateDepartment(DepartmentRequestBody dept) {
        Department dt = new Department();
        BeanUtils.copyProperties(dept, dt);
        return repo.save(dt);
    }
}
