package com.example.soham.test.model;

import javax.persistence.*;

@Entity
@Table(name="controller_new_table", catalog = "new_database")
public class Controller {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;
    @ManyToOne(targetEntity = Student.class, cascade = CascadeType.ALL)
    @JoinColumn(referencedColumnName = "id")
    Student student;
    @ManyToOne(targetEntity = Department.class, cascade = CascadeType.ALL)
    @JoinColumn(referencedColumnName = "id")
    Department dept;
    @ManyToOne(targetEntity = Teacher.class, cascade = CascadeType.ALL)
    @JoinColumn(referencedColumnName = "id")
    Teacher teacher;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Department getDept() {
        return dept;
    }

    public void setDept(Department dept) {
        this.dept = dept;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
}
