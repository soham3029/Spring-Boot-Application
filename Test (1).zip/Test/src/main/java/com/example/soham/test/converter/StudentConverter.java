package com.example.soham.test.converter;

import com.example.soham.test.dto.StudentDto;
import com.example.soham.test.model.Student;
import com.example.soham.test.requestbody.StudentRequestBody;

import java.util.List;
import java.util.stream.Collectors;

public class StudentConverter {
    public StudentDto entityToDto(StudentRequestBody student)
    {
        StudentDto dto = new StudentDto();
        dto.setId(student.getId());
        dto.setName(student.getName());
        dto.setEmail(student.getEmail());
        dto.setMarks(student.getMarks());
        return dto;
    }
    public List<StudentDto> entityToDto(List<StudentRequestBody> student)
    {
        return student.stream().map(x -> entityToDto(x)).collect(Collectors.toList());
    }
    public StudentRequestBody dtoToEntity(StudentDto dto)
    {
        StudentRequestBody st = new StudentRequestBody();
        st.setId(dto.getId());
        st.setName(dto.getName());
        st.setEmail(dto.getEmail());
        st.setMarks(dto.getMarks());
        return st;
    }
    public List<StudentRequestBody> dtoToEntity(List<StudentDto> dto)
    {
        return dto.stream().map(x -> dtoToEntity(x)).collect(Collectors.toList());
    }
}
