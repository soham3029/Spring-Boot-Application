package com.example.soham.test.dto;

import com.example.soham.test.model.Department;

public class TeacherDto {
    private int id;
    private String tname;
    private Department dept;

    public Department getDept() {
        return dept;
    }

    public TeacherDto() {
        super();
    }

    public TeacherDto(String tname) {
        this.tname = tname;
    }

    public void setDept(Department dept) {
        this.dept = dept;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }
}
