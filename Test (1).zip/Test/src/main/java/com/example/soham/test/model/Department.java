package com.example.soham.test.model;

import javax.persistence.*;

@Entity
@Table(name="dept_new_name", catalog="new_database")
public class Department {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int id;
    private String dname;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }
}
