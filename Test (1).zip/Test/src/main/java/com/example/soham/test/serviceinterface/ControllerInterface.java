package com.example.soham.test.serviceinterface;

import com.example.soham.test.model.Controller;
import com.example.soham.test.requestbody.ControllerRequestBody;

public interface ControllerInterface {
    public Controller saveController(ControllerRequestBody cr);
    public Controller updateController(ControllerRequestBody cr);
    public void deleteById(int id);
}
