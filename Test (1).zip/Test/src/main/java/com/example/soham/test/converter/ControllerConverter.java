package com.example.soham.test.converter;

import com.example.soham.test.dto.ControllerDto;
import com.example.soham.test.model.Controller;
import com.example.soham.test.requestbody.ControllerRequestBody;

import java.util.List;
import java.util.stream.Collectors;

public class ControllerConverter {
    public ControllerDto entityToDto(ControllerRequestBody cnr)
    {
        ControllerDto dto = new ControllerDto();
        dto.setId(cnr.getId());
        dto.setSid(cnr.getSid());
        dto.setDid(cnr.getDid());
        dto.setTid(cnr.getTid());
        return dto;
    }
    public List<ControllerDto> entityToDto(List<ControllerRequestBody> cnr)
    {
        return cnr.stream().map(x->entityToDto(x)).collect(Collectors.toList());
    }
    public ControllerRequestBody dtoToEntity(ControllerDto dto)
    {
        ControllerRequestBody cnr = new ControllerRequestBody();
        cnr.setId(dto.getId());
        cnr.setSid(dto.getSid());
        cnr.setDid(dto.getDid());
        cnr.setTid(dto.getTid());
        return cnr;
    }
    public List<ControllerRequestBody> dtoToEntity(List<ControllerDto> dto)
    {
        return dto.stream().map(x->dtoToEntity(x)).collect(Collectors.toList());
    }
}
