package com.example.soham.test.requestbody;

public class DepartmentRequestBody {
    private int id;
    private String dname;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }
}
