package com.example.soham.test.model;

import javax.persistence.*;
import java.util.Optional;

@Entity
@Table(name="teacher_new_table", catalog = "new_database")
public class Teacher {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String tname;
    @OneToOne(targetEntity = Department.class, cascade = CascadeType.ALL)
    @JoinColumn(referencedColumnName = "id")
    Department dept;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Department getDept() {
        return dept;
    }

    public void setDept(Department dept) {
        this.dept = dept;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }
}
