package com.example.soham.test.dto;

public class ControllerDto {
    int id;
    int did;
    int sid;
    int tid;

    public ControllerDto() {
    }

    public ControllerDto(int id) {
        this.id = id;
    }

    public ControllerDto(int did, int tid) {
        this.did = did;
        this.tid = tid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }
}
