package com.example.soham.test.serviceinterface;


import com.example.soham.test.dto.StudentDto;
import com.example.soham.test.model.Student;
import com.example.soham.test.requestbody.StudentRequestBody;

public interface StudentInterface {
    public Student saveStudent(StudentRequestBody student);
    public Student updateStudent(StudentRequestBody student);
    public void deleteById(int id);

}
