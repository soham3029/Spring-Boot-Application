package com.example.soham.test.serviceimplementation;

import com.example.soham.test.dao.ControllerRepository;
import com.example.soham.test.dao.DepartmentRepository;
import com.example.soham.test.dao.StudentRepository;
import com.example.soham.test.dto.DepartmentDto;
import com.example.soham.test.dto.StudentDto;
import com.example.soham.test.model.Department;
import com.example.soham.test.model.Student;
import com.example.soham.test.requestbody.StudentRequestBody;
import com.example.soham.test.serviceinterface.StudentInterface;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class StudentImpl implements StudentInterface {
    @Autowired
    private StudentRepository repo;
    @Autowired
    private DepartmentRepository deptrepo;

    @Override
    public Student saveStudent(StudentRequestBody student) {
        Student st = new Student();
        BeanUtils.copyProperties(student, st);
        Department dept = deptrepo.findById(student.getDid());
        st.setDept(dept);
        return repo.save(st);
    }

    @Override
    public Student updateStudent(StudentRequestBody student) {
        Student st = new Student();
        BeanUtils.copyProperties(student, st);
        return repo.save(st);
    }

    @Override
    public void deleteById(int id) {
        repo.deleteById(id);

    }
    public List<StudentDto> passedSuccessfully(int marks)
    {
        return repo.passedSuccessfully(marks);
    }
    public List<Student> findByName(String name)
    {
        return repo.findByName(name);
    }
}
