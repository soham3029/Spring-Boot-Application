package com.example.soham.test.controller;


import com.example.soham.test.TestApplication;
import com.example.soham.test.converter.StudentConverter;
import com.example.soham.test.dto.ControllerDto;
import com.example.soham.test.dto.StudentDto;
import com.example.soham.test.dto.TeacherDto;
import com.example.soham.test.model.Controller;
import com.example.soham.test.model.Department;
import com.example.soham.test.model.Student;
import com.example.soham.test.model.Teacher;
import com.example.soham.test.requestbody.ControllerRequestBody;
import com.example.soham.test.requestbody.DepartmentRequestBody;
import com.example.soham.test.requestbody.StudentRequestBody;
import com.example.soham.test.requestbody.TeacherRequestBody;
import com.example.soham.test.serviceimplementation.ControllerImpl;
import com.example.soham.test.serviceimplementation.DepartmentImpl;
import com.example.soham.test.serviceimplementation.StudentImpl;
import com.example.soham.test.serviceimplementation.TeacherImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class HomeController {
    public static final Logger logger = LoggerFactory.getLogger(TestApplication.class);

    @Autowired
    private ControllerImpl coimpl;
    @Autowired
    private StudentImpl stimpl;
    @Autowired
    TeacherImpl timpl;
    @Autowired
    DepartmentImpl dimpl;



    @PostMapping("saveStudent")
    public Student saveStudent(@RequestBody StudentRequestBody st)
    {
        return stimpl.saveStudent(st);
    }
    @PutMapping("updateStudent")
    public Student updateStudent(@RequestBody StudentRequestBody st)
    {
        return stimpl.updateStudent(st);
    }
    @DeleteMapping("deleteById")
    public String deleteById(@RequestBody int id)
    {
        stimpl.deleteById(id);
        return "Student Deleted";
    }
    @GetMapping("passedSuccessfulStudent")
    public List<StudentDto> passedSuccessful(@RequestParam int marks)
    {
        return stimpl.passedSuccessfully(marks);
    }
    @GetMapping("findByFirstname")
    public List<Student> findByFirstName(@RequestParam String name)
    {
        return stimpl.findByName(name);
    }
    
    @PostMapping("saveTeacher")
    public Teacher saveTeacher(@RequestBody TeacherRequestBody tc)
    {
        return timpl.saveTeacher(tc);
    }
    @PutMapping("updateTeacher")
    public Teacher updateTeacher(@RequestBody TeacherRequestBody tc)
    {
        return timpl.updateTeacher(tc);
    }
    @DeleteMapping("deleteTeacher")
    public String deleteByTid(@RequestParam int id)
    {
        timpl.deleteByTid(id);
        return "Teacher Deleted";
    }
    @GetMapping("findTeacherByDeptId")
    public List<TeacherDto> findByDeptId(@RequestParam int id)
    {
        return timpl.findByDeptId(id);
    }
    @PostMapping("saveDepartment")
    public Department saveDepartment(@RequestBody DepartmentRequestBody dc)
    {
        return dimpl.saveDepartment(dc);
    }
    @PutMapping("updateDepartment")
    public Department updateDepartment(@RequestBody DepartmentRequestBody dc)
    {
        return dimpl.updateDepartment(dc);
    }
    @PostMapping("saveController")
    public Controller saveController(@RequestBody ControllerRequestBody cnr)
    {
        return coimpl.saveController(cnr);
    }
    @PutMapping("updateController")
    public Controller updateController(@RequestBody ControllerRequestBody cnr)
    {
        return coimpl.updateController(cnr);
    }
    @DeleteMapping("deleteController")
    public String deleteByControllerId(@RequestParam int id)
    {
        coimpl.deleteById(id);
        return "Controller data deleted";
    }
}
