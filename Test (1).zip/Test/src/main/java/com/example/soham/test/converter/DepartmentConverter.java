package com.example.soham.test.converter;

import com.example.soham.test.dto.DepartmentDto;
import com.example.soham.test.requestbody.DepartmentRequestBody;

import java.util.List;
import java.util.stream.Collectors;

public class DepartmentConverter {
    public DepartmentDto entityToDto(DepartmentRequestBody dept)
    {
        DepartmentDto dto = new DepartmentDto();
        dto.setId(dept.getId());
        dto.setDname(dept.getDname());
        return dto;
    }
    public List<DepartmentDto> entityToDto(List<DepartmentRequestBody> dept)
    {
        return dept.stream().map(x->entityToDto(x)).collect(Collectors.toList());
    }
    public DepartmentRequestBody dtoToEntity(DepartmentDto dto)
    {
        DepartmentRequestBody dept = new DepartmentRequestBody();
        dept.setId(dto.getId());
        dept.setDname(dto.getDname());
        return dept;
    }
    public List<DepartmentRequestBody> dtoToEntity(List<DepartmentDto> dto)
    {
        return dto.stream().map(x->dtoToEntity(x)).collect(Collectors.toList());
    }
}
